# Iviwe Hlatana - Portfolio Website

A modern, responsive portfolio website showcasing software development expertise, AI/ML knowledge, and professional projects. Built with clean HTML5, CSS3, and vanilla JavaScript for optimal performance and compatibility.

## Features

### Design & UX Enhancements
- **Modern Dark Theme** with gradient backgrounds and smooth transitions
- **Fully Responsive** design that works seamlessly on all devices (mobile, tablet, desktop)
- **Smooth Scrolling** navigation with active page indicators
- **Mobile-Friendly Navigation** with hamburger menu for smaller screens
- **Glassmorphism Effects** with backdrop blur for modern aesthetics
- **Smooth Animations** including fade-in, slide-in, and floating effects
- **Gradient Text** for visual hierarchy and modern styling

## Sections Included

1. **Home Page** - Professional introduction with animated typing effect
2. **Skills Page** - Software Development, AI, and Testing expertise
3. **Education Page** - Timeline of academic qualifications
4. **Projects Page** - Showcase of AI and no-code projects
5. **Contact Page** - Social media links and contact options

## Technical Stack

- **HTML5** - Semantic markup with proper meta tags
- **CSS3** - Advanced styling with animations, gradients, and responsive design
- **JavaScript** - Vanilla JS for mobile menu and interactions (no dependencies)

## Responsive Design

Optimized for all screen sizes:
- Desktop (1024px+) - Full navigation bar
- Tablet (768px-1023px) - Adjusted layouts
- Mobile (480px-767px) - Hamburger menu
- Small Mobile (<480px) - Optimized layouts

## File Structure

```
portfolio-enhanced/
├── index.html              # Home page
├── styles.css              # Global stylesheet
├── skills/skills.html      # Skills page
├── education/education.html # Education page
├── projects/projects.html  # Projects page
├── contact/contact.html    # Contact page
├── index/IVIWE.jpg        # Profile image
└── README.md              # This file
```

## Deployment on Netlify

### Quick Start
1. Push to GitHub
2. Connect repository to Netlify
3. Deploy automatically

### Manual Deployment
1. Zip the portfolio folder
2. Drag and drop on Netlify
3. Site goes live instantly

### Custom Domain
1. Add domain in Netlify settings
2. Update DNS records
3. Site accessible at your custom domain

## Key Improvements

✅ Fixed broken navigation links
✅ Added responsive mobile menu with hamburger toggle
✅ Unified CSS across all pages (single stylesheet)
✅ Added proper meta tags for SEO
✅ Completed animations with smooth effects
✅ Enhanced visual design with gradients and effects
✅ Improved accessibility with proper alt text
✅ Better typography and spacing
✅ Modern glassmorphism effects
✅ Smooth hover interactions

## Color Scheme

- **Primary**: #b74b4b (Red/Crimson)
- **Background**: #0a0a0a to #1a1a1a (Dark gradient)
- **Text**: #ffffff (White) and #d0d0d0 (Light gray)
- **Accent**: #ff6b6b (Bright red)

## Browser Support

- Chrome (latest)
- Firefox (latest)
- Safari (latest)
- Edge (latest)
- Mobile browsers

## Customization

### Change Colors
Edit `styles.css` and replace color values:
- Primary: `#b74b4b`
- Gradients: Update gradient definitions

### Update Content
- Edit HTML files directly
- Replace profile image: `index/IVIWE.jpg`
- Modify text in respective pages

### Add New Sections
1. Create new HTML file
2. Copy header/nav structure
3. Link in all navigation menus
4. Add styles if needed

## Performance

- No external dependencies
- Optimized CSS with no redundancy
- Fast loading times
- Mobile-first design
- Smooth CSS animations

---

**Version**: 2.0 (Enhanced)
**Last Updated**: December 2024
