# Portfolio Deployment Guide

## Quick Start - Deploy in 5 Minutes

### Option 1: Deploy via Netlify (Recommended)

#### Step 1: Push to GitHub
```bash
# Initialize git (if not already done)
git init
git add .
git commit -m "Initial portfolio commit"

# Create a new repository on GitHub
# Then push your code:
git remote add origin https://github.com/YOUR_USERNAME/portfolio.git
git branch -M main
git push -u origin main
```

#### Step 2: Connect to Netlify
1. Go to [netlify.com](https://netlify.com)
2. Click "Sign up" or "Log in"
3. Click "New site from Git"
4. Select GitHub and authorize Netlify
5. Choose your portfolio repository
6. Click "Deploy site"

**That's it!** Your site will be live at `https://your-site-name.netlify.app`

#### Step 3: Custom Domain (Optional)
1. In Netlify dashboard, go to "Domain settings"
2. Click "Add custom domain"
3. Enter your domain name
4. Follow DNS configuration instructions
5. Wait for DNS to propagate (usually 24-48 hours)

---

### Option 2: Manual Deployment

#### Step 1: Zip Your Portfolio
```bash
# From the portfolio-enhanced directory
zip -r portfolio.zip .
```

#### Step 2: Deploy on Netlify
1. Go to [netlify.com/drop](https://netlify.com/drop)
2. Drag and drop your `portfolio.zip` file
3. Your site goes live instantly!

---

## File Structure

Make sure your portfolio has this structure:
```
portfolio/
├── index.html              # Home page
├── styles.css              # Global stylesheet
├── README.md              # Project info
├── DEPLOYMENT_GUIDE.md    # This file
├── skills/
│   └── skills.html
├── education/
│   └── education.html
├── projects/
│   └── projects.html
├── contact/
│   └── contact.html
└── index/
    └── IVIWE.jpg          # Your profile image
```

---

## Before Deployment Checklist

- [ ] All links are working (test locally first)
- [ ] Profile image is in the correct location
- [ ] All page titles are correct
- [ ] Contact links point to correct email/social profiles
- [ ] No console errors (check browser dev tools)
- [ ] Responsive design works on mobile (test with browser dev tools)
- [ ] All external links open in new tabs (target="_blank")

---

## Testing Locally

### Using Python (Recommended)
```bash
cd portfolio-enhanced
python3 -m http.server 8000
```
Then visit: `http://localhost:8000`

### Using Node.js
```bash
npx http-server
```

---

## Customization Before Deployment

### Update Your Information

1. **Home Page** (`index.html`)
   - Change the Download Resume link to your actual resume
   - Update the introduction text

2. **Skills Page** (`skills/skills.html`)
   - Add/remove skills as needed
   - Update skill descriptions

3. **Education Page** (`education/education.html`)
   - Update your education details
   - Change dates and institutions

4. **Projects Page** (`projects/projects.html`)
   - Update project links
   - Add new projects or remove existing ones
   - Update project descriptions

5. **Contact Page** (`contact/contact.html`)
   - Update LinkedIn URL
   - Update GitHub URL
   - Update email address

### Change Colors

Edit `styles.css` and find these color values:
- Primary color: `#b74b4b` (replace with your color)
- Accent: `#ff6b6b` (replace with your color)

Search and replace all instances.

### Update Profile Image

1. Replace `index/IVIWE.jpg` with your own image
2. Keep the same filename or update the path in `index.html`
3. Recommended size: 400x400px (square image)
4. Format: JPG, PNG, or WebP

---

## Troubleshooting

### Links Not Working
- Make sure all relative paths are correct
- Use `../` to go up one directory level
- Test locally before deploying

### Images Not Showing
- Check image file paths in HTML
- Make sure image files exist in the correct directory
- Use relative paths, not absolute paths

### Styling Issues
- Clear browser cache (Ctrl+Shift+Delete or Cmd+Shift+Delete)
- Make sure `styles.css` is in the root directory
- Check that all CSS links are correct

### Mobile Menu Not Working
- Check browser console for JavaScript errors
- Make sure you're using the latest version of the files
- Test on actual mobile device, not just browser dev tools

---

## Performance Tips

1. **Optimize Images**
   - Compress your profile image
   - Use tools like [TinyPNG](https://tinypng.com)
   - Recommended: Under 200KB per image

2. **Enable Caching**
   - Netlify handles caching automatically
   - No additional configuration needed

3. **Monitor Performance**
   - Use [Google PageSpeed Insights](https://pagespeed.web.dev)
   - Check Netlify analytics for visitor insights

---

## SEO Optimization

Your portfolio includes:
- ✅ Meta descriptions on all pages
- ✅ Proper heading hierarchy (H1, H2, H3)
- ✅ Alt text on images
- ✅ Mobile-friendly design
- ✅ Fast loading times

To improve further:
1. Add Google Analytics (in Netlify dashboard)
2. Submit sitemap to Google Search Console
3. Use descriptive page titles

---

## Need Help?

### Netlify Support
- [Netlify Docs](https://docs.netlify.com)
- [Netlify Community](https://community.netlify.com)

### General Web Development
- [MDN Web Docs](https://developer.mozilla.org)
- [CSS-Tricks](https://css-tricks.com)

---

## Version History

- **v2.0** (December 2024) - Enhanced design with animations, responsive mobile menu, unified CSS
- **v1.0** - Original portfolio

---

**Happy deploying! 🚀**
